Introduction
------------

The pandastable library provides a table widget for Tkinter with
plotting and data manipulation functionality. It uses the pandas
DataFrame class to store table data. Pandas is an open source Python
library providing high-performance data structures and data analysis
tools. Tkinter is the standard GUI toolkit for python. It is intended
for the following uses:

-  for python/tkinter GUI developers who want to include a table in
   their application that can store and process large amounts of data
-  for non-programmers who are not familiar with Python or the pandas
   API and want to use the included DataExplore application to
   manipulate/view their data
-  it may also be useful for data analysts and programmers who want to
   get an initial interactive look at their tabular data without coding

The DataExplore application
---------------------------

Installing the package creates a command *dataexplore* in your path.
Just run this to open the program. This is a standalone application for
data manipulation and plotting meant for education and basic data
analysis. See the home page for this application at
http://dmnfarrell.github.io/pandastable/

Links
-----

http://openresearchsoftware.metajnl.com/articles/10.5334/jors.94/

http://dmnfarrell.github.io/pandastable/

https://youtu.be/Ss0QIFywt74



